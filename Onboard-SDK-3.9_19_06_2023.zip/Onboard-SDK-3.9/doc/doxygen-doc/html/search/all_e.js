var searchData=
[
  ['obtainctrlauthority',['obtainCtrlAuthority',['../classDJI_1_1OSDK_1_1Vehicle.html#a9d126654855a4ab0e6184cf9b2c0d14b',1,'DJI::OSDK::Vehicle::obtainCtrlAuthority(VehicleCallBack callback=0, UserData userData=0)'],['../classDJI_1_1OSDK_1_1Vehicle.html#ada0f01f29348a0ba1f9ca9d254643c92',1,'DJI::OSDK::Vehicle::obtainCtrlAuthority(int timeout)']]],
  ['openheader',['OpenHeader',['../structDJI_1_1OSDK_1_1OpenHeader.html',1,'DJI::OSDK::OpenHeader'],['../namespaceDJI_1_1OSDK.html#a516293d5bd31dcc42f62375ca91b3971',1,'DJI::OSDK::OpenHeader()']]]
];
