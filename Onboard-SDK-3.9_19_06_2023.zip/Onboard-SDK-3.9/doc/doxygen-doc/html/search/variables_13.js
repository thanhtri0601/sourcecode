var searchData=
[
  ['velocityned',['velocityNED',['../structDJI_1_1OSDK_1_1Telemetry_1_1GPSInfo.html#a7d2b3fc5198b2cc74958fa4e6f8b82a2',1,'DJI::OSDK::Telemetry::GPSInfo::velocityNED()'],['../structDJI_1_1OSDK_1_1Telemetry_1_1RTK.html#a523524d5cf3bb9658b512a9371c897de',1,'DJI::OSDK::Telemetry::RTK::velocityNED()'],['../structDJI_1_1OSDK_1_1Telemetry_1_1LegacyGPSInfo.html#a5d559102da8f35bb0110c88d5a1b86a0',1,'DJI::OSDK::Telemetry::LegacyGPSInfo::velocityNED()']]],
  ['version',['version',['../structDJI_1_1OSDK_1_1HotPointSettings.html#a789cd78691d550c40ee73e3005851c9f',1,'DJI::OSDK::HotPointSettings']]],
  ['versionbase33',['versionBase33',['../namespaceDJI_1_1OSDK.html#a3dd4c9d507013d951308a115913ceb76',1,'DJI::OSDK']]],
  ['video',['video',['../structDJI_1_1OSDK_1_1Telemetry_1_1LB2RcFullRawData.html#a630fadcd8b72b92933c6b69b97f5c2fc',1,'DJI::OSDK::Telemetry::LB2RcFullRawData']]],
  ['videopause',['videoPause',['../structDJI_1_1OSDK_1_1Telemetry_1_1LB2RcFullRawData.html#a27852fb3e1dfdff30e9e9038440311d7',1,'DJI::OSDK::Telemetry::LB2RcFullRawData']]],
  ['visiblesatellitenumber',['visibleSatelliteNumber',['../structDJI_1_1OSDK_1_1Telemetry_1_1GPSFused.html#a2f01aa648a30661094c996eaad1dfbf2',1,'DJI::OSDK::Telemetry::GPSFused']]],
  ['voltage',['voltage',['../structDJI_1_1OSDK_1_1Telemetry_1_1ESCStatusIndividual.html#a84dd585d87bc97361e20fb2724a99ed0',1,'DJI::OSDK::Telemetry::ESCStatusIndividual']]]
];
