var searchData=
[
  ['takeoff',['takeoff',['../classDJI_1_1OSDK_1_1Control.html#a7f79c6ed6e9c399fff2354d0403be6f5',1,'DJI::OSDK::Control::takeoff(int wait_timeout)'],['../classDJI_1_1OSDK_1_1Control.html#a4ffefbdc320fde5d8403f1d20d82a192',1,'DJI::OSDK::Control::takeoff(VehicleCallBack callback=0, UserData userData=0)']]],
  ['title',['title',['../classDJI_1_1OSDK_1_1Log.html#af9373914bf75d6b77c779098ea04f474',1,'DJI::OSDK::Log::title(int level, const char *prefix, const char *func, int line)'],['../classDJI_1_1OSDK_1_1Log.html#a73d0b45d5dd739c74145c37b0db2718e',1,'DJI::OSDK::Log::title(int level, const char *prefix)']]]
];
