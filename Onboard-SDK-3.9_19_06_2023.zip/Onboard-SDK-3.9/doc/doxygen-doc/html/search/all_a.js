var searchData=
[
  ['kill_5fswitch_5fon',['KILL_SWITCH_ON',['../classDJI_1_1OSDK_1_1ErrorCode_1_1CommonACK.html#a8f92bc51bf0ad447335642a36f65f450',1,'DJI::OSDK::ErrorCode::CommonACK']]],
  ['killswitch',['KillSwitch',['../classDJI_1_1OSDK_1_1Control.html#a2d81493e9c6b0246811cbe71d8825db6',1,'DJI::OSDK::Control::KillSwitch()'],['../classDJI_1_1OSDK_1_1Control.html#a2a70c775ac5032cd3ea9e7ef8eb4fc41',1,'DJI::OSDK::Control::killSwitch(KillSwitch cmd, int wait_timeout=10, char debugMsg[10]=(char *)&quot;OSDK_API&quot;)'],['../classDJI_1_1OSDK_1_1Control.html#a7ec01e6bc9bd8f113581860a0a5debc4',1,'DJI::OSDK::Control::killSwitch(KillSwitch cmd, char debugMsg[10]=(char *)&quot;OSDK_API&quot;, VehicleCallBack callback=0, UserData userData=0)']]]
];
