var searchData=
[
  ['advancedctrldata',['AdvancedCtrlData',['../classDJI_1_1OSDK_1_1Control.html#ab7ea2c02a75d2a31942c9e29d92aa397',1,'DJI::OSDK::Control']]],
  ['angledata',['AngleData',['../classDJI_1_1OSDK_1_1Gimbal.html#a9cd1690d79f6e16d1ddd37f18cf4c69b',1,'DJI::OSDK::Gimbal']]]
];
