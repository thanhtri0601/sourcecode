var searchData=
[
  ['unbalanced',['unbalanced',['../structDJI_1_1OSDK_1_1Telemetry_1_1ESCStatusIndividual.html#aec128d93bc2c3b546393c79e190283ae',1,'DJI::OSDK::Telemetry::ESCStatusIndividual']]],
  ['unrecorded_5fhome',['UNRECORDED_HOME',['../structDJI_1_1OSDK_1_1ErrorCode_1_1MissionACK_1_1Common.html#a99a154ed3a1956310727b1cdea613cac',1,'DJI::OSDK::ErrorCode::MissionACK::Common']]],
  ['unsubscribefctimeinutcref',['unsubscribeFCTimeInUTCRef',['../classDJI_1_1OSDK_1_1HardwareSync.html#a61a4446558a06f726b8f2721e1baad5d',1,'DJI::OSDK::HardwareSync']]],
  ['unsubscribenmeamsgs',['unsubscribeNMEAMsgs',['../classDJI_1_1OSDK_1_1HardwareSync.html#a335a945e5a0425d8afc3902749892428',1,'DJI::OSDK::HardwareSync']]],
  ['unsubscribeppssource',['unsubscribePPSSource',['../classDJI_1_1OSDK_1_1HardwareSync.html#a37a321ce0be787c5fea542fa8cd87615',1,'DJI::OSDK::HardwareSync']]],
  ['unsubscribeutctime',['unsubscribeUTCTime',['../classDJI_1_1OSDK_1_1HardwareSync.html#aec86984217521ea987df4b0a01adf02c',1,'DJI::OSDK::HardwareSync']]],
  ['up',['up',['../structDJI_1_1OSDK_1_1Telemetry_1_1RelativePosition.html#a69ac12205c74bc918548b3e582a34fc8',1,'DJI::OSDK::Telemetry::RelativePosition']]],
  ['updateidlevelocity',['updateIdleVelocity',['../classDJI_1_1OSDK_1_1WaypointMission.html#affd964d55236c2ba99ce790f7ba1efa2',1,'DJI::OSDK::WaypointMission::updateIdleVelocity(float32_t meterPreSecond, VehicleCallBack callback=0, UserData userData=0)'],['../classDJI_1_1OSDK_1_1WaypointMission.html#afe0ba7a20c4a882d9e2b3052feb69a29',1,'DJI::OSDK::WaypointMission::updateIdleVelocity(float32_t meterPreSecond, int timeout)']]],
  ['updateradius',['updateRadius',['../classDJI_1_1OSDK_1_1HotpointMission.html#a23db500bffe71b0dca90c70b10e751d4',1,'DJI::OSDK::HotpointMission::updateRadius(float32_t meter, VehicleCallBack callback=0, UserData userData=0)'],['../classDJI_1_1OSDK_1_1HotpointMission.html#aafa97568c631a714657f6ec94694f792',1,'DJI::OSDK::HotpointMission::updateRadius(float32_t meter, int timer)']]],
  ['updateyawrate',['updateYawRate',['../classDJI_1_1OSDK_1_1HotpointMission.html#aa73b985636b20e5449c2da4eaf98517c',1,'DJI::OSDK::HotpointMission::updateYawRate(YawRate &amp;Data, VehicleCallBack callback=0, UserData userData=0)'],['../classDJI_1_1OSDK_1_1HotpointMission.html#a2649be5171a2e6f02ff96022423a7f32',1,'DJI::OSDK::HotpointMission::updateYawRate(YawRate &amp;Data, int timer)'],['../classDJI_1_1OSDK_1_1HotpointMission.html#a2999fe48791ddefe9c75a98ef7f58996',1,'DJI::OSDK::HotpointMission::updateYawRate(float32_t yawRate, bool isClockwise, VehicleCallBack callback=0, UserData userData=0)']]],
  ['uphealth',['upHealth',['../structDJI_1_1OSDK_1_1Telemetry_1_1RelativePosition.html#a3c80fb248c45c7fdfc7d6d840525b22d',1,'DJI::OSDK::Telemetry::RelativePosition']]],
  ['uploadindexdata',['uploadIndexData',['../classDJI_1_1OSDK_1_1WaypointMission.html#a0923b487adb4c6968268914baebd880c',1,'DJI::OSDK::WaypointMission::uploadIndexData(WayPointSettings *data, VehicleCallBack callback=0, UserData userData=0)'],['../classDJI_1_1OSDK_1_1WaypointMission.html#a5a96fe056a51d025c9f269e81c997d7c',1,'DJI::OSDK::WaypointMission::uploadIndexData(WayPointSettings *data, int timer)']]],
  ['uploadindexdatacallback',['uploadIndexDataCallback',['../classDJI_1_1OSDK_1_1WaypointMission.html#ae09771749e867713524fae85f96ed4e1',1,'DJI::OSDK::WaypointMission']]],
  ['usedgln',['usedGLN',['../structDJI_1_1OSDK_1_1Telemetry_1_1GPSDetail.html#a90abfb74dd921e1faa066ce7d014565b',1,'DJI::OSDK::Telemetry::GPSDetail']]],
  ['usedgps',['usedGPS',['../structDJI_1_1OSDK_1_1Telemetry_1_1GPSDetail.html#a5f75f4d81f2cd4168e9d248ad9c3f4a6',1,'DJI::OSDK::Telemetry::GPSDetail']]],
  ['userdata',['UserData',['../namespaceDJI_1_1OSDK.html#aded24c93a2d064658a1f59cbf0e6eb9d',1,'DJI::OSDK']]]
];
