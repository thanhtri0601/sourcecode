var searchData=
[
  ['killswitch',['killSwitch',['../classDJI_1_1OSDK_1_1Control.html#a2a70c775ac5032cd3ea9e7ef8eb4fc41',1,'DJI::OSDK::Control::killSwitch(KillSwitch cmd, int wait_timeout=10, char debugMsg[10]=(char *)&quot;OSDK_API&quot;)'],['../classDJI_1_1OSDK_1_1Control.html#a7ec01e6bc9bd8f113581860a0a5debc4',1,'DJI::OSDK::Control::killSwitch(KillSwitch cmd, char debugMsg[10]=(char *)&quot;OSDK_API&quot;, VehicleCallBack callback=0, UserData userData=0)']]]
];
